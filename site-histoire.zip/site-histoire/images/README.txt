Les images des carrousels seront déposées ici.
